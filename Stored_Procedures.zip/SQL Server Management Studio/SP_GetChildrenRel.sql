CREATE PROCEDURE [dbo].[SP_GetChildrenRel]
	@Person1Id INT,
	@Person2Id INT
AS
	BEGIN
			CREATE TABLE #Person1Children (PersonId INT, FirstName VARCHAR(50),
			LastName VARCHAR(50), Gender CHAR(1), BirthDate DATETIME2, 
			DeathDate DATETIME2, TreeId INT, Generation INT)
			INSERT INTO #Person1Children
			EXEC SP_GetChildren @Person1Id

			CREATE TABLE #Person2Children (PersonId INT, FirstName VARCHAR(50),
			LastName VARCHAR(50), Gender CHAR(1), BirthDate DATETIME2, 
			DeathDate DATETIME2, TreeId INT, Generation INT)
			INSERT INTO #Person2Children
			EXEC SP_GetChildren @Person2Id

			SELECT P.PersonId, P.FirstName, P.LastName, P.Gender,
			P.BirthDate, P.DeathDate, P.TreeId, P.Generation
			FROM #Person1Children P 
			JOIN #Person2Children Q
			ON P.PersonId = Q.PersonId
			ORDER BY P.BirthDate ASC
	END
			

