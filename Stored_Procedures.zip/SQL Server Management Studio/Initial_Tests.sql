INSERT INTO [dbo].[User]([UserName],[Password],[IsAdmin]) VALUES
		('Mel',dbo.SF_HashPassword('lalala'), 1)

INSERT INTO Tree(TreeName, UserId)
VALUES ('My Tree', 1)

INSERT INTO Person(FirstName, LastName, Gender, BirthDate, TreeId)
VALUES ('Mel', 'Colmant', 'm', '1983-02-24', 1),
		('Noemie', 'Colmant', 'f', '1985-06-01', 1),
		('Xavier', 'Colmant', 'm', '1960-08-09', 1),
		('Oph�lie', 'Colmant', 'f', '1987-10-22', 1),
		('Chantal', 'Hainaut', 'f', '1957-03-06', 1),
		('Tim', 'Colmant', 'm', '1989-11-11', 1)

SELECT * FROM Person

INSERT INTO ParentChild (Person1Id, Person2Id, IsAdopted)
VALUES (3, 1, 0), (3, 2, 0), (3, 4, 0), (3, 6, 0), 
(5, 1, 0), (5, 2, 0), (5, 4, 0), (5, 6, 0)

SELECT * FROM ParentChild


INSERT INTO Person(FirstName, LastName, Gender, BirthDate, TreeId)
VALUES ('Femme1', 'Num1', 'f', '1983-02-24', 1),
		('Femme2', 'Num2', 'f', '1985-06-01', 1),
		('Femme3', 'Num3', 'f', '1960-08-09', 1),
		('Femme4', 'Num4', 'f', '1987-10-22', 1),
		('Femme5', 'Num5', 'f', '1957-03-06', 1)

INSERT INTO RelationshipType(RelationshipTypeCode, RelationshipTypeName)
	VALUES('p', 'Partners'),('f', 'Fianc�s'),('m', 'Married')

INSERT INTO Relationship(Person1Id, Person2Id, StartDate, IsUnisex, RelationshipTypeCode)
	VALUES(1,7, '2015-01-01', 0, 'p'),(1,8, '2016-01-01', 0, 'f'), (1,6, '2017-01-01', 1, 'p'),(1,9, '2018-02-21', 0, 'm')

INSERT INTO Relationship(Person1Id, Person2Id, StartDate, IsUnisex, RelationshipTypeCode)
	VALUES(1,7, '2015-01-01', 0, 'p'),(8,1, '2016-01-01', 0, 'f'), (11,10, '2017-01-01', 1, 'p')

SELECT * FROM Relationship
