CREATE PROCEDURE [dbo].[SP_DeletePerson]
	@PersonId INT
AS 
	DELETE FROM Person 
	WHERE PersonId = @PersonId