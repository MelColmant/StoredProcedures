CREATE PROCEDURE [dbo].[SP_UpdateParentChild]
	@ParentChildId INT,
	@Person1Id INT,
	@Person2Id INT,
	@IsAdopted BIT,
	@TreeId INT
AS
	UPDATE ParentChild
	SET Person1Id = @Person1Id,
	Person2Id = @Person2Id,
	IsAdopted = @IsAdopted,
	TreeId = @TreeId
	WHERE ParentChildId = @ParentChildId