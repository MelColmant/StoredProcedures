CREATE PROCEDURE [dbo].[SP_ParentChildGetAll]
AS
	SELECT ParentChildId, Person1Id, Person2Id, IsAdopted, TreeId
	FROM ParentChild