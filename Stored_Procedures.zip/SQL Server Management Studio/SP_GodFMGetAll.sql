CREATE PROCEDURE [dbo].[SP_GodFMGetAll]

AS
	SELECT GodFMId, Person1Id, Person2Id
	FROM GodFM