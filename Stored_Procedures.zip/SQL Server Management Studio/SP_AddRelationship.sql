CREATE PROCEDURE [dbo].[SP_AddRelationship]
	@Person1Id INT,
	@Person2Id INT,
	@StartDate DATETIME2,
	@EndDate DATETIME2 = NULL,
	@IsUnisex BIT,
	@RelationshipTypeCode CHAR(1)
AS
	INSERT INTO Relationship(Person1Id, Person2Id, StartDate,
							EndDate, IsUnisex, RelationshipTypeCode)
	OUTPUT INSERTED.RelationshipId
	VALUES(@Person1Id, @Person2Id, @StartDate, @EndDate, @IsUnisex,
	@RelationshipTypeCode)