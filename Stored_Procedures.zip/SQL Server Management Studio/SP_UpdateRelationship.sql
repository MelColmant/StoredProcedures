CREATE PROCEDURE [dbo].[SP_UpdateRelationship]
	@RelationshipId INT,
	@Person1Id INT,
	@Person2Id INT,
	@StartDate DATETIME2,
	@EndDate DATETIME2 = NULL,
	@IsUnisex BIT,
	@RelationshipTypeCode CHAR(1)
AS
	UPDATE Relationship
	SET Person1Id = @Person1Id,
	Person2Id = @Person2Id,
	StartDate = @StartDate,
	EndDate = @EndDate,
	IsUnisex = @IsUnisex,
	RelationshipTypeCode = @RelationshipTypeCode
	WHERE RelationshipId = @RelationshipId