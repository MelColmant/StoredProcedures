CREATE PROCEDURE [dbo].[SP_ParentChildGetOne]
	@ParentChildId INT
AS
	SELECT ParentChildId, Person1Id, Person2Id, IsAdopted
	FROM ParentChild
	WHERE ParentChildId = @ParentChildId