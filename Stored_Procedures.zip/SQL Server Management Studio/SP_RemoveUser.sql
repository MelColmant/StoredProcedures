CREATE PROCEDURE [dbo].[SP_RemoveUser]
	@UserId INT
AS
	DELETE FROM [dbo].[User] 
	WHERE UserId = @UserId
