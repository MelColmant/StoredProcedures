CREATE PROCEDURE [dbo].[SP_Person_RessourceGetOne]
	@Person_RessourceId INT
AS
	SELECT Person_RessourceId, PersonId, RessourceId
	FROM Person_Ressource
	WHERE Person_RessourceId = @Person_RessourceId