CREATE VIEW [View_GetChildren]
AS
	SELECT * FROM dbo.SF_GetChildren(1)