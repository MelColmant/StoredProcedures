CREATE PROCEDURE [dbo].[SP_Add_User]
	@UserName NVARCHAR(32),
	@Password NVARCHAR(32),
	@IsAdmin BIT
AS
	INSERT INTO [User](Username, [Password], IsAdmin)
	OUTPUT INSERTED.UserId
	VALUES(@Username,[dbo].SF_HashPassword(@password),@IsAdmin)
