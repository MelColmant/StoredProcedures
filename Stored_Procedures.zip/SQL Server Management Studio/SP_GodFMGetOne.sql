CREATE PROCEDURE [dbo].[SP_GodFMGetOne]
	@GodFMId INT
AS
	SELECT GodFMId, Person1Id, Person2Id
	FROM GodFM
	WHERE GodFMId = @GodFMId