CREATE PROCEDURE [dbo].[SP_RelationshipGetOne]
	@RelationshipId INT
AS 
	SELECT RelationshipId, Person1Id, Person2Id, StartDate,
	EndDate, IsUnisex, RelationshipTypeCode
	FROM Relationship WHERE RelationshipId = @RelationshipId