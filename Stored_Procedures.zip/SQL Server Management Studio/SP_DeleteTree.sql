CREATE PROCEDURE [dbo].[SP_DeleteTree]
	@TreeId INT
AS
	DELETE FROM Tree 
	WHERE TreeId = @TreeId