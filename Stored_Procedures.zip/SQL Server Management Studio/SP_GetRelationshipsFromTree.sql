CREATE PROCEDURE [dbo].[SP_GetRelationshipsFromTree]
	@TreeId INT
AS
	SELECT * FROM Relationship 
	WHERE TreeId = @TreeId