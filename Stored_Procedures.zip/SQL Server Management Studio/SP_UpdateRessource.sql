CREATE PROCEDURE [dbo].[SP_UpdateRessource]
	@RessourceId INT,
	@Format NVARCHAR(50),
	@Description NVARCHAR(255),
	@Link NVARCHAR(255)
AS
	UPDATE Ressources
	SET [Format] = @Format,
	[Description] = @Description,
	Link = @Link
	WHERE RessourceId = @RessourceId