CREATE PROCEDURE [dbo].[SP_DeletePerson_Ressource]
	@Person_RessourceId INT
AS
	DELETE FROM Person_Ressource
	WHERE Person_RessourceId = @Person_RessourceId