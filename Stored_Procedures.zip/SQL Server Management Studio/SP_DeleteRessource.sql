CREATE PROCEDURE [dbo].[SP_DeleteRessource]
	@RessourceId INT
AS
	DELETE FROM Ressources 
	WHERE RessourceId = @RessourceId