CREATE PROCEDURE [dbo].[SP_GetRelationships]
	@PersonId INT
AS
	CREATE TABLE #RelationshipTable (RelationshipId INT, Person1Id INT, Person2Id INT,
									StartDate DATETIME2, EndDate DATETIME2, 
									IsUniSex BIT, RelationshipTypeCode CHAR(1),
									TreeId INT)
	
	INSERT INTO #RelationshipTable 
	SELECT R.RelationshipId, R.Person1Id, P.PersonId, R.StartDate, 
	R.EndDate, R.IsUnisex, R.RelationshipTypeCode, R.TreeId
	FROM Person P 
	JOIN Relationship R
	ON P.PersonId = R.Person2Id
	WHERE R.Person1Id = @PersonId

	INSERT INTO #RelationshipTable 
	SELECT R.RelationshipId, R.Person2Id, PersonId, R.StartDate, 
	R.EndDate, R.IsUnisex, R.RelationshipTypeCode, R.TreeId
	FROM Person P 
	JOIN Relationship R
	ON P.PersonId = R.Person1Id
	WHERE R.Person2Id = @PersonId

	SELECT * FROM #RelationshipTable
	ORDER BY StartDate DESC