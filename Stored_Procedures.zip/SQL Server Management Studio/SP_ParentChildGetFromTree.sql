CREATE PROCEDURE [dbo].[SP_ParentChildGetFromTree]
	@TreeId INT
AS
	SELECT ParentChildId, Person1Id, Person2Id, IsAdopted, TreeId
	FROM ParentChild WHERE TreeId = @TreeId