CREATE PROCEDURE [dbo].[SP_GodFMUpdate]
	@GodFMId INT,
	@Person1Id INT,
	@Person2Id INT
AS
	UPDATE GodFM
	SET Person1Id = @Person1Id,
	Person2Id= @Person2Id
	WHERE GodFMId = @GodFMId

