CREATE PROCEDURE [dbo].[SP_AddRessource]
	@Format NVARCHAR(50),
	@Description NVARCHAR(255),
	@Link NVARCHAR(255)

AS
	INSERT INTO Ressources
	([Format], [Description], Link)
	OUTPUT INSERTED.RessourceId
	VALUES(@Format, @Description, @Link)
