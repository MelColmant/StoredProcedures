DROP DATABASE FamilyTree

CREATE DATABASE FamilyTree

/*Need to move to FamilyTree DB Folder first */

CREATE TABLE [User] (
	UserId INT IDENTITY(1,1),
	UserName NVARCHAR(32) NOT NULL,
	[Password] VARBINARY(32) NOT NULL,
	IsAdmin BIT NOT NULL,
	CONSTRAINT PK_User PRIMARY KEY(UserId),
	CONSTRAINT UK_UserName UNIQUE(UserName)
	);

CREATE TABLE Tree (
	TreeId INT IDENTITY(1,1),
	TreeName NVARCHAR(50) NOT NULL,
	[Description] NVARCHAR(255), 
	UserId INT NOT NULL,
	CONSTRAINT PK_Tree PRIMARY KEY(TreeId),
	CONSTRAINT UK_TreeName UNIQUE(TreeName),
	CONSTRAINT FK_Tree_User FOREIGN KEY(UserId) REFERENCES [User](UserId) ON DELETE CASCADE
	);

CREATE TABLE Person (
	PersonId INT IDENTITY(1,1),
	FirstName NVARCHAR(50) NOT NULL,
	LastName NVARCHAR(50) NOT NULL,
	Gender CHAR(1) NOT NULL,
	BirthDate DATETIME2 NOT NULL,
	DeathDate DATETIME2,
	TreeId INT NOT NULL,
	Generation INT NOT NULL,
	CONSTRAINT PK_Person PRIMARY KEY(PersonId),
	CONSTRAINT FK_Person_Tree FOREIGN KEY(TreeId) REFERENCES Tree(TreeId) ON DELETE CASCADE
	);

CREATE TABLE Ressources (
	RessourceId INT IDENTITY(1,1),
	[Format] NVARCHAR(50) NOT NULL,
	[Description] NVARCHAR(255) NOT NULL,
	Link NVARCHAR(255) NOT NULL,
	CONSTRAINT PK_Ressources PRIMARY KEY(RessourceId)
	);

CREATE TABLE Person_Ressource (
	Person_RessourceId INT IDENTITY(1,1),
	PersonId INT NOT NULL,
	RessourceId INT NOT NULL,
	CONSTRAINT PK_Person_Ressource PRIMARY KEY(Person_RessourceId),
	CONSTRAINT FK_Person_Ressource_Person FOREIGN KEY(PersonId) REFERENCES Person(PersonId) ON DELETE CASCADE,
	CONSTRAINT FK_Person_Ressource_Ressources FOREIGN KEY(RessourceId) REFERENCES Ressources(RessourceId) ON DELETE CASCADE
	);

CREATE TABLE RelationshipType (
	RelationshipTypeCode CHAR(1),
	RelationshipTypeName NVARCHAR(50),
	CONSTRAINT PK_RelationshipType PRIMARY KEY(RelationshipTypeCode),
	CONSTRAINT UK_RelationshipTypeCode UNIQUE(RelationshipTypeCode)
	);

CREATE TABLE Relationship (
	RelationshipId INT IDENTITY(1,1),
	Person1Id INT NOT NULL,
	Person2Id INT NOT NULL,
	StartDate DATETIME2 NOT NULL,
	EndDate DATETIME2,
	IsUnisex BIT NOT NULL,
	RelationshipTypeCode CHAR(1),
	TreeId INT NOT NULL,
	CONSTRAINT PK_Relationship PRIMARY KEY(RelationshipId),
	CONSTRAINT FK_Relationship_Person1 FOREIGN KEY(Person1Id) REFERENCES Person(PersonId) ON DELETE CASCADE,
	CONSTRAINT FK_Relationship_Person2 FOREIGN KEY(Person2Id) REFERENCES Person(PersonId),
	CONSTRAINT FK_Relationship_RelationshipType FOREIGN KEY(RelationshipTypeCode) REFERENCES RelationshipType(RelationshipTypeCode),
	CONSTRAINT FK_Relationship_Tree FOREIGN KEY(TreeId) REFERENCES Tree(TreeId)
	);

CREATE TABLE ParentChild (
	ParentChildId INT IDENTITY(1,1),
	Person1Id INT NOT NULL,
	Person2Id INT NOT NULL,
	IsAdopted BIT NOT NULL,
	TreeId INT NOT NULL,
	CONSTRAINT PK_ParentChild PRIMARY KEY(ParentChildId),
	CONSTRAINT FK_ParentChild_Person1 FOREIGN KEY(Person1Id) REFERENCES Person(PersonId) ON DELETE CASCADE,
	CONSTRAINT FK_ParentChild_Person2 FOREIGN KEY(Person2Id) REFERENCES Person(PersonId),
	CONSTRAINT FK_ParentChild_Tree FOREIGN KEY(TreeId) REFERENCES Tree(TreeId)
	);

CREATE TABLE GodFM (
	GodFMId INT IDENTITY(1,1),
	Person1Id INT NOT NULL,
	Person2Id INT NOT NULL,
	CONSTRAINT PK_GodFM PRIMARY KEY(GodFMId),
	CONSTRAINT FK_GodFM_Person1 FOREIGN KEY(Person1Id) REFERENCES Person(PersonId) ON DELETE CASCADE,
	CONSTRAINT FK_GodFM_Person2 FOREIGN KEY(Person2Id) REFERENCES Person(PersonId)
	);





	



