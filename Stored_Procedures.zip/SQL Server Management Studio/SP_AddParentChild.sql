CREATE PROCEDURE [dbo].[SP_AddParentChild]
	@Person1Id INT,
	@Person2Id INT,
	@IsAdopted BIT
AS
	BEGIN
		IF NOT EXISTS (SELECT * FROM ParentChild 
						WHERE Person1Id = @Person1Id
						AND Person2ID = @Person2Id)
		BEGIN
			INSERT INTO [dbo].[ParentChild](Person1Id, Person2Id, IsAdopted)
			OUTPUT Inserted.ParentChildId
			VALUES (@Person1Id, @Person2Id, @IsAdopted)
		END
	END