CREATE PROCEDURE [dbo].[SP_AddTree]
	@TreeName NVARCHAR(50),
	@Description NVARCHAR(255),
	@UserId INT
AS
	BEGIN
		DECLARE @Result BIT
		SET @Result = (SELECT IsAdmin FROM [User] WHERE UserId = @UserId)
		IF @Result = 1
		BEGIN
		INSERT INTO Tree(TreeName, [Description], UserId)
		OUTPUT INSERTED.TreeId
		VALUES(@TreeName,@Description,@UserId)
		END
	END