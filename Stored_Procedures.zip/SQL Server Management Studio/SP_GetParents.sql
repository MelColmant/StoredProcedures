CREATE PROCEDURE [dbo].[SP_GetParents]
	@PersonId INT
AS
	SELECT P.PersonId, P.FirstName, P.LastName, P.Gender,
	P.BirthDate, P.DeathDate, P.TreeId
	FROM Person P 
	JOIN ParentChild Q
	ON P.PersonId = Q.Person1Id
	WHERE Q.Person2Id = @PersonId


