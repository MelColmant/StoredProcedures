CREATE FUNCTION [dbo].[SF_GetChildren]
(
@PersonId INT
)
RETURNS TABLE
AS
RETURN 
	SELECT P.PersonId, P.FirstName, P.LastName
	FROM Person P 
	JOIN ParentChild Q ON 
	P.Person1Id = Q.Person2Id
	WHERE Q.Person1Id = @PersonId
