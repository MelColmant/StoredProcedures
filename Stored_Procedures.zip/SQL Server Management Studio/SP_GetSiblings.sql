CREATE PROCEDURE [dbo].[SP_GetSiblings]
	@PersonId INT
AS
	CREATE TABLE #ParentTable (PersonId INT, FirstName NVARCHAR(50), LastName NVARCHAR(50), Gender CHAR(1),
								BirthDate DATETIME2, DeathDate DATETIME2, TreeId INT)

	INSERT INTO #ParentTable EXEC [dbo].[SP_GetParents] @PersonId
	
	CREATE TABLE #P1ChildrenTable (PersonId INT, FirstName NVARCHAR(50), LastName NVARCHAR(50), Gender CHAR(1),
									BirthDate DATETIME2, DeathDate DATETIME2, TreeId INT)
	DECLARE @Id1 INT
	SET @Id1 = (SELECT TOP 1 PersonId FROM #ParentTable)
	INSERT INTO #P1ChildrenTable EXEC [dbo].[SP_GetChildren] @Id1

	CREATE TABLE #P2ChildrenTable (PersonId INT, FirstName NVARCHAR(50), LastName NVARCHAR(50), Gender CHAR(1),
									BirthDate DATETIME2, DeathDate DATETIME2, TreeId INT)
	DECLARE @Id2 INT
	SET @Id2 = (SELECT TOP 1 PersonId FROM #ParentTable ORDER BY PersonId DESC)
	INSERT INTO #P2ChildrenTable EXEC [dbo].[SP_GetChildren] @Id2

	SELECT P.PersonId, P.FirstName, P.LastName, P.Gender,
	P.BirthDate, P.DeathDate, P.TreeId
	FROM #P1ChildrenTable P
	JOIN #P2ChildrenTable Q
	ON P.PersonId = Q.PersonId
	WHERE P.PersonId != @PersonId