CREATE PROCEDURE [dbo].[SP_AddSiblings]
	@Person1Id INT,
	@Person2Id INT,
	@Is2Adopted BIT
AS
	BEGIN
		IF EXISTS (SELECT * FROM ParentChild 
					WHERE Person2Id = @Person1Id)
		BEGIN
			CREATE TABLE #ParentsTable (Person1Id INT, Person2Id INT, IsAdopted BIT)
			INSERT INTO #ParentsTable 
			SELECT Person1Id, Person2Id, IsAdopted
			FROM ParentChild
			WHERE Person2Id = @Person1Id

			UPDATE #ParentsTable 
			SET Person2Id = @Person2Id,
			IsAdopted = @Is2Adopted

			INSERT INTO ParentChild
			SELECT * FROM #ParentsTable
		END
	END