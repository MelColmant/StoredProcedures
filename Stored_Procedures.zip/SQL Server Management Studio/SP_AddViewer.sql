CREATE PROCEDURE [dbo].[SP_AddViewer]
	@userName NVARCHAR(32),
	@password NVARCHAR(64)
AS
	INSERT INTO [dbo].[User]([UserName],[Password],[IsAdmin]) VALUES
	(@userName,dbo.SF_HashPassword(@password), 0)