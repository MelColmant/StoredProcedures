CREATE PROCEDURE [dbo].[SP_PersonGetOne]
	@PersonId INT
AS 
	SELECT PersonId, FirstName, LastName, Gender,
	BirthDate, DeathDate, TreeId
	FROM Person WHERE PersonId = @PersonId