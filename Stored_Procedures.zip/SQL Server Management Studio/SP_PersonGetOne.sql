CREATE PROCEDURE [dbo].[SP_PersonGetOne]
	@PersonId INT
AS 
	SELECT PersonId, FirstName, LastName, Gender,
	BirthDate, DeathDate, TreeId, Generation
	FROM Person WHERE PersonId = @PersonId