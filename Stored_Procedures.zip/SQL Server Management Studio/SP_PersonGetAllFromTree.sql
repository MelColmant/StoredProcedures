CREATE PROCEDURE [dbo].[SP_PersonGetAllFromTree]
	@TreeId INT
AS
	SELECT PersonId, FirstName, LastName, Gender,
	BirthDate, DeathDate, TreeId 
	FROM Person
	WHERE TreeId = @TreeId