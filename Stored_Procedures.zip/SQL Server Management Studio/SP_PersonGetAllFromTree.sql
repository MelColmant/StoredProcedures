CREATE PROCEDURE [dbo].[SP_PersonGetAllFromTree]
	@TreeId INT
AS
	SELECT PersonId, FirstName, LastName, Gender,
	BirthDate, DeathDate, TreeId, Generation
	FROM Person
	WHERE TreeId = @TreeId
	ORDER BY Generation DESC, BirthDate