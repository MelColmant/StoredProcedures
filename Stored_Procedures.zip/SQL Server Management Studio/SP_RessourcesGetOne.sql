CREATE PROCEDURE [dbo].[SP_RessourcesGetOne]
	@RessourceId INT
AS
	SELECT RessourceId, [Format], [Description], Link
	FROM Ressources
	WHERE RessourceId = @RessourceId