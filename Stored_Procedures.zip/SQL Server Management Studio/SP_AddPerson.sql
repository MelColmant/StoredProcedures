CREATE PROCEDURE [dbo].[SP_AddPerson]
	@FirstName NVARCHAR(50),
	@LastName NVARCHAR(50),
	@Gender CHAR(1),
	@BirthDate DATETIME2,
	@DeathDate DATETIME2,
	@TreeId INT,
	@Generation INT
AS
	BEGIN
		IF EXISTS (SELECT * FROM Tree
					WHERE TreeId = @TreeId)
		BEGIN
			INSERT INTO Person(FirstName, LastName, Gender,
			BirthDate, DeathDate, TreeId, Generation)
			OUTPUT INSERTED.PersonId
			VALUES(@FirstName, @LastName, @Gender, @BirthDate,
			@DeathDate, @TreeId, @Generation)
		END
	END
