CREATE PROCEDURE [dbo].[SP_DeleteRelationship]
	@RelationshipId INT
AS 
	DELETE FROM Relationship 
	WHERE RelationshipId = @RelationshipId