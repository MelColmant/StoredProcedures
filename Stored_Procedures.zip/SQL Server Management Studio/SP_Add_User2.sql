ALTER PROCEDURE [dbo].[SP_Add_User]
	@UserName NVARCHAR(32),
	@Password NVARCHAR(32),
	@IsAdmin BIT
AS
	BEGIN
		IF NOT EXISTS (SELECt Username FROM [User]
						WHERE Username = @Username)
		BEGIN
			INSERT INTO [User](Username, [Password], IsAdmin)
			OUTPUT INSERTED.UserId
			VALUES(@Username,[dbo].SF_HashPassword(@password),@IsAdmin)		
		END
	END