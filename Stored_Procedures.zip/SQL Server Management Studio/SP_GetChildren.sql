CREATE PROCEDURE [dbo].[SP_GetChildren]
	@PersonId INT
AS
	SELECT P.PersonId, P.FirstName, P.LastName, P.Gender,
	P.BirthDate, P.DeathDate, P.TreeId, P.Generation
	FROM Person P 
	JOIN ParentChild Q
	ON P.PersonId = Q.Person2Id
	WHERE Q.Person1Id = @PersonId

