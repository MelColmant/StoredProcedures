CREATE PROCEDURE [dbo].[SP_TreeGetOne]
	@TreeId INT
AS 
	SELECT TreeId, TreeName, [Description], UserId 
	FROM Tree WHERE TreeId = @TreeId