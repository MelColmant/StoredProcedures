CREATE PROCEDURE [dbo].[SP_Person_RessourceGetAll]

AS
	SELECT Person_RessourceId, PersonId, RessourceId
	FROM Person_Ressource