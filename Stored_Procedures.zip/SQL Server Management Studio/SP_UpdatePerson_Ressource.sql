CREATE PROCEDURE [dbo].[SP_UpdatePerson_Ressource]
	@Person_RessourceId INT,
	@PersonId INT,
	@RessourceId INT
AS
	UPDATE Person_Ressource
	SET PersonId = @PersonId,
	RessourceId = @RessourceId
	WHERE Person_RessourceId = @Person_RessourceId