CREATE PROCEDURE [dbo].[SP_CheckUser]
	@userName NVARCHAR(32),
	@password NVARCHAR(64)
AS
	IF EXISTS(
		SELECT UserId
		FROM [dbo].[User]
		WHERE UserName = @userName
		AND [Password] = dbo.SF_HashPassword(@password))
		SELECT UserId, UserName, IsAdmin FROM [User] WHERE UserName = @UserName