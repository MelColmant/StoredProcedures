CREATE PROCEDURE [dbo].[SP_CheckUser]
	@userName NVARCHAR(32),
	@password NVARCHAR(64),
	@userId INT OUTPUT
AS
	SET @userId = 0;
	IF EXISTS(
		SELECT UserId
		FROM [dbo].[User]
		WHERE UserName = @userName
		AND [Password] = dbo.SF_HashPassword(@password))
		SELECT @userId = UserId FROM [User] WHERE UserName = @UserName
RETURN 0

