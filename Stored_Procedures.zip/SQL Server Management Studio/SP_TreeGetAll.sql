CREATE PROCEDURE [dbo].[SP_TreeGetAll]

AS
	SELECT TreeId, TreeName, [Description], UserId FROM Tree
