CREATE PROCEDURE [dbo].[SP_PersonUpdate]
	@PersonId INT,
	@FirstName VARCHAR(50),
	@LastName VARCHAR(50),
	@Gender CHAR(1),
	@BirthDate DATETIME2,
	@DeathDate DATETIME2 = NULL,
	@TreeId INT
AS
	UPDATE Person
	SET FirstName = @FirstName,
	LastName= @LastName,
	Gender = @Gender,
	BirthDate = @BirthDate,
	DeathDate = @DeathDate,
	TreeId = @TreeId
	WHERE PersonId = @PersonId

