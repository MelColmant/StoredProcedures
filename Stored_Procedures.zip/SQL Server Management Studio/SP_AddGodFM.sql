CREATE PROCEDURE [dbo].[SP_AddGodFM]
	@Person1Id INT,
	@Person2Id INT

AS
	BEGIN
		IF EXISTS (SELECT * FROM Person
					WHERE PersonId = @Person1Id)
					AND EXISTS
					(SELECT * FROM Person
					WHERE PersonId = @Person2Id)
		BEGIN
			INSERT INTO GodFM(Person1Id, Person2Id)
			OUTPUT INSERTED.GodFMId
			VALUES(@Person1Id, @Person2Id)
		END
	END