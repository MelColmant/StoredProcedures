CREATE PROCEDURE [dbo].[SP_AddPersonRessource]
	@PersonId INT,
	@RessourceId INT
AS
	INSERT INTO Person_Ressource(PersonId, RessourceId)
	OUTPUT INSERTED.Person_RessourceId
	VALUES(@PersonId, @RessourceId)