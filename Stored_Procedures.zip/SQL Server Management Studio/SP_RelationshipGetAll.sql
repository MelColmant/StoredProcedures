CREATE PROCEDURE [dbo].[SP_RelationshipGetAll]

AS
	SELECT RelationshipId, Person1Id, Person2Id, StartDate,
	EndDate, IsUnisex, RelationshipTypeCode, TreeId FROM Relationship