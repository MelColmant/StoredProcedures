CREATE PROCEDURE [dbo].[SP_UpdateTree]
	@TreeId INT,
	@TreeName VARCHAR(50),
	@Description VARCHAR(255) = NULL
AS
	UPDATE Tree
	SET TreeName = @TreeName,
	[Description] = @Description
	WHERE TreeId = @TreeId