CREATE PROCEDURE [dbo].[SP_PersonGetAll]

AS
	SELECT PersonId, FirstName, LastName, Gender,
	BirthDate, DeathDate, TreeId, Generation FROM Person