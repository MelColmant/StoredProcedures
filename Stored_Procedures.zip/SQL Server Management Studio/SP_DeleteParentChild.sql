CREATE PROCEDURE [dbo].[SP_DeleteParentChild]
	@ParentChildId INT
AS
	DELETE FROM ParentChild 
	WHERE ParentChildId = @ParentChildId