CREATE PROCEDURE [dbo].[SP_RessourcesGetAll]

AS
	SELECT RessourceId, [Format], [Description], Link
	FROM Ressources